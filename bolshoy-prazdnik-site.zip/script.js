function openForm() {
  document.getElementById("callbackForm").style.display = "block";
}

function closeForm() {
  document.getElementById("callbackForm").style.display = "none";
}
